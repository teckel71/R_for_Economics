# Archivo: R/MATcor.R

#' MATcor: Matriz de correlaci\u00F3n gr\u00E1fica
#'
#' Esta funci\u00F3n crea una matriz de correlaci\u00F3n gr\u00E1fica entre variables m\u00E9tricas de un dataframe.
#' Permite seleccionar un subconjunto espec\u00EDfico de variables.
#'
#' @param data Dataframe con los datos.
#' @param ... Variables espec\u00EDficas (sin comillas) a incluir en la matriz de correlaci\u00F3n.
#' @return Devuelve (y adem\u00E1s guarda en el entorno global) una lista con el gr\u00E1fico de correlaciones.
#' @importFrom rlang quos
#' @export
MATcor <- function(data, ...) {
  if (!requireNamespace("GGally", quietly = TRUE)) {
    stop("Falta el paquete 'GGally'. Inst\u00E1lalo con install.packages('GGally').", call. = FALSE)
  }
  if (!requireNamespace("dplyr", quietly = TRUE)) {
    stop("Falta el paquete 'dplyr'. Inst\u00E1lalo con install.packages('dplyr').", call. = FALSE)
  }
  if (!requireNamespace("rlang", quietly = TRUE)) {
    stop("Falta el paquete 'rlang'. Inst\u00E1lalo con install.packages('rlang').", call. = FALSE)
  }

  variables <- rlang::quos(...)

  data_used <- if (length(variables) > 0) {
    dplyr::select(data, !!!variables)
  } else {
    dplyr::select(data, dplyr::where(is.numeric))
  }

  if (ncol(data_used) < 2) {
    stop("El dataframe debe contener al menos dos variables num\u00E9ricas para calcular la correlaci\u00F3n.", call. = FALSE)
  }

  corr_plot <- GGally::ggpairs(
    data_used,
    lower = list(
      continuous = GGally::wrap("cor", size = 4.5, method = "pearson", stars = TRUE)
    ),
    title = "Matriz de Correlaci\u00F3n"
  )

  # --- Compatibilidad con gu\u00EDa/pr\u00E1cticas ---
  # La gu\u00EDa y los PDFs del curso asumen que la funci\u00F3n crea un objeto en el
  # Global Environment con el nombre: <data>_correlaciones_info
  df_name <- deparse(substitute(data))
  out <- list(correlaciones = corr_plot, data = data_used)
  assign(paste0(df_name, "_correlaciones_info"), out, envir = .GlobalEnv)

  out
}
