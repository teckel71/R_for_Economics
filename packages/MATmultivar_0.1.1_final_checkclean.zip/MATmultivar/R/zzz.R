# Internal: declare global variables used in tidy eval / ggplot2
utils::globalVariables(c(
  "GRUPO",
  "Componente",
  "Autovalor",
  "Varianza_Acumulada",
  ".case_id"
))
