# Archivo: R/MATcor.R

#' MATcor: Matriz de correlación gráfica
#'
#' Esta función crea una matriz de correlación gráfica entre variables métricas de un dataframe.
#' Permite seleccionar un subconjunto específico de variables.
#'
#' @param data Dataframe con los datos.
#' @param ... Variables específicas (sin comillas) a incluir en la matriz de correlación.
#' @return Devuelve (y además guarda en el entorno global) una lista con el gráfico de correlaciones.
#' @importFrom rlang quos
#' @export
MATcor <- function(data, ...) {
  if (!requireNamespace("GGally", quietly = TRUE)) {
    stop("Falta el paquete 'GGally'. Instálalo con install.packages('GGally').", call. = FALSE)
  }
  if (!requireNamespace("dplyr", quietly = TRUE)) {
    stop("Falta el paquete 'dplyr'. Instálalo con install.packages('dplyr').", call. = FALSE)
  }
  if (!requireNamespace("rlang", quietly = TRUE)) {
    stop("Falta el paquete 'rlang'. Instálalo con install.packages('rlang').", call. = FALSE)
  }

  variables <- rlang::quos(...)

  data_used <- if (length(variables) > 0) {
    dplyr::select(data, !!!variables)
  } else {
    dplyr::select(data, dplyr::where(is.numeric))
  }

  if (ncol(data_used) < 2) {
    stop("El dataframe debe contener al menos dos variables numéricas para calcular la correlación.", call. = FALSE)
  }

  corr_plot <- GGally::ggpairs(
    data_used,
    lower = list(
      continuous = GGally::wrap("cor", size = 4.5, method = "pearson", stars = TRUE)
    ),
    title = "Matriz de Correlación"
  )

  # --- Compatibilidad con guía/prácticas ---
  # La guía y los PDFs del curso asumen que la función crea un objeto en el
  # Global Environment con el nombre: <data>_correlaciones_info
  df_name <- deparse(substitute(data))
  out <- list(correlaciones = corr_plot, data = data_used)
  assign(paste0(df_name, "_correlaciones_info"), out, envir = .GlobalEnv)

  out
}
